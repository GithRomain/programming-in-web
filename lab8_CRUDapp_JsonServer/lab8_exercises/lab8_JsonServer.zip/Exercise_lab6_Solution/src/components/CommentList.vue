<template>
    <div>
        <div class="uk-overflow-auto">
            <form class="uk-margin uk-flex">
                <input v-model="query" type="search" class="uk-input" placeholder="Author...">
                <button @click.prevent="findComments" class="uk-button uk-button-primary">Search</button>
            </form>

            <table class="uk-table uk-table-middle uk-table-divider">
                <thead>
                <tr>
                    <th class="uk-width-small">Author</th>
                    <th class="uk-table-expand">Message</th>
                    <th class="uk-width-small">Action</th>
                </tr>
                </thead>

                <tbody>
                <Comment v-for="comment in comments" :key="comment.id"
                         :comment="comment"></Comment>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
import Comment from "./Comment"

export default {
    name: 'CommentList',
    data() {
        return {
            comments: [],
            query: "",
        }
    },
    components: {
        "Comment": Comment
    },
    methods: {
        deleteComment: function(id) {
            this.FakeDataService.delete(id)
            this.getAllComments()
        },
        getAllComments: function() {
            this.comments = this.FakeDataService.getAll()
        },
        findComments: function() {
            if (this.query.trim() === "") {
                return this.getAllComments()
            }

            this.comments = this.FakeDataService.find(this.query)
        }
    },
    mounted() {
        this.getAllComments()
    }
}
</script>
