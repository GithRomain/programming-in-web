<template>
    <div>
        <form>
            <fieldset class="uk-fieldset">
                <legend class="uk-legend">Add comment</legend>

                <div class="uk-margin">
                    <input v-model="author" :class="{'uk-form-danger': invalidAuthor}" class="uk-input" type="text" placeholder="author">
                </div>

                <div class="uk-margin">
                    <textarea v-model="message" :class="{'uk-form-danger': invalidMessage}" class="uk-textarea" rows="5" placeholder="Message"></textarea>
                </div>

                <button @click.prevent="addComment" class="uk-button uk-button-primary">Add</button>
            </fieldset>
        </form>
    </div>
</template>

<script>
import UIkit from 'uikit';

export default {
    name: 'AddComment',
    data() {
        return {
            author: "",
            invalidAuthor: false,

            message: "",
            invalidMessage: false,

            successAlert: false
        }
    },
    methods: {
        addComment: function() {
            this.invalidAuthor = false;
            this.invalidMessage = false;

            if (this.author.trim() === "") this.invalidAuthor = true;
            if (this.message.trim() === "") this.invalidMessage = true;

            if (this.invalidAuthor || this.invalidMessage) return;

            this.FakeDataService.create({
                author: this.author,
                message: this.message,
            })

            this.author = this.message = "";
            UIkit.notification("Comment added successfully", {status: "success", timeout: 3000, pos: "top-left"});
        },
    }
}
</script>
