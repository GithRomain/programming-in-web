<template>
    <tr>
        <td>{{ comment.author }}</td>
        <td><span v-if="show">{{ comment.message }}</span></td>
        <td>
            <div class="uk-button-group">
                <button @click="toggle" class="uk-button uk-button-primary">
                    {{ show ? "hide" : "show" }}
                </button>
                <button @click="deleteComment" class="uk-button uk-button-danger">
                    Delete
                </button>
            </div>
        </td>
    </tr>
</template>

<script>
export default {
    name: 'Comment',
    data() {
        return {
            show: true
        }
    },
    props: {
        "comment": {
            type: Object,
            required: true
        }
    },
    methods: {
        toggle: function () {
            this.show = !this.show
        },
        deleteComment: function() {
            this.$parent.deleteComment(this.comment.id)
        }
    }
}
</script>

<style scoped>
i {
    cursor: pointer;
}
</style>
