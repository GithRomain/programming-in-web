import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import FakeDataService from "./FakeDataService";

const app = createApp(App)

app.config.globalProperties.FakeDataService = new FakeDataService();
app.use(router).mount('#app')
