class FakeDataService {
    comments = []

    constructor() {
        this.comments = [
            {"id": 0, "author": "John Doe", "message": "Hello There"},
            {"id": 1, "author": "Jane Doe", "message": "Hi, this is a comment"},
            {"id": 2, "author": "Bruce Lee", "message": "A comment from Bruce"},
            {"id": 3, "author": "John Doe", "message": "My second comment from John"},
            {"id": 4, "author": "Jane Doe", "message": "And same, my second comment from Jane"},
        ]
    }

    getAll() {
        return this.comments
    }

    find(author) {
        return this.comments.filter(comment => comment.author.toLowerCase().includes(author.toLowerCase()))
    }


    create(data) {
        let id = this.comments.reduce((prev, curr) => (prev.id > curr.id) ? prev : curr).id + 1;

        this.comments.push({
            id: id,
            ...data
        })
    }


    delete(id) {
        this.comments = this.comments.filter(comment => comment.id !== parseInt(id))
    }
}

export default FakeDataService;
