<template>
    <div id="nav">
        <nav class="uk-navbar-container" uk-navbar>
            <div class="uk-navbar-center">
                <ul class="uk-navbar-nav">
                    <router-link to="/"
                                 v-slot="{ href, navigate, isActive }"
                                 custom>
                        <li :class="{'uk-active': isActive}">
                            <a :href="href" @click="navigate">Home</a>
                        </li>
                    </router-link>
                    <router-link to="/AddComment"
                                 v-slot="{ href, navigate, isActive }"
                                 custom>
                        <li :class="{'uk-active': isActive}">
                            <a :href="href" @click="navigate">Add comment</a>
                        </li>
                    </router-link>
                </ul>
            </div>
        </nav>
    </div>

    <div class="uk-container uk-margin-top">
        <router-view/>
    </div>
</template>

<script>
import UIkit from 'uikit';
import Icons from 'uikit/dist/js/uikit-icons';

UIkit.use(Icons);

export default {
    name: 'App',
}
</script>

<style>
@import "../node_modules/uikit/dist/css/uikit.min.css";
</style>
