import { createRouter, createWebHistory } from 'vue-router'
import AddComment from '../components/AddComment.vue'
import CommentList from '../components/CommentList.vue'
import NotFound from '../error-pages/NotFound.vue'


const routes = [
  {
    path: '/',
    name: 'CommentList',
    component: CommentList
  },
  {
    path: '/AddComment',
    name: 'AddComment',
    component: AddComment
  },
  {
    path: '/:catchAll(.*)*',
    name: 'NotFound',
    component: NotFound
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
