import { createApp } from 'vue';

import App from './App.vue';
import CountryItem from './components/CountryItem.vue';

const app = createApp(App);

app.component('CountryItem', CountryItem);

app.mount('#app');
