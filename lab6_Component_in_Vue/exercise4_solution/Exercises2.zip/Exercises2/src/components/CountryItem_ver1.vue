<template>
  <li>
	<h2>{{ name }}</h2>
    <button @click="toggleDetails()">
        {{ detailsAreVisible ? 'Hide' : 'Show' }} Details
    </button>
    <ul v-if="detailsAreVisible">
       <li><strong>Area:</strong> {{ countryArea }}</li>
       <li><strong>Population:</strong> {{ countryPopulation }}</li>
    </ul>
  </li>
</template>

<script>
export default {
  props: [
    'name',
    'countryArea',
    'countryPopulation'
  ],
  data() {
    return {
      detailsAreVisible: false,
      country: {
          id: 'PL',
          name: 'POLAND',
          area: '312 tys',
          population: '38 mln',
      },
    };
  },
  methods: {
    toggleDetails() {
      this.detailsAreVisible = !this.detailsAreVisible;
    }
  }
};
</script>