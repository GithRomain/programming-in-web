<template>
  <section>
    <h2>My Countries</h2>
    <ul>
      <li></li>
    </ul>
  </section>
</template>

<script>
export default {
  data() {
    return {
      countries: [
        {
          id: 'PL',
          name: 'POLAND',
          area: '312 tys',
          population: '38 mln',
        },
        {
          id: 'FR',
          name: 'FRANCE',
          area: ' 675,4 tys',
          population: '68 mln',
        },
      ],
    };
  },
};
</script>