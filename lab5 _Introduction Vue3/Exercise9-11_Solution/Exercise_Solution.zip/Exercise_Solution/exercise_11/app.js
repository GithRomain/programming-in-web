const app = Vue.createApp({
  data() {
    return { 
       newCountry: '',
       countries: [],
	   taskListIsVisible: true,
     };
  },
  computed: {
    buttonCaption() {
      return this.taskListIsVisible ? 'Hide List' : 'Show List';
    },
  },
  methods: {
    addCountry() {
      this.countries.push(this.newCountry);
    },
    removeCountry(idx) {
      this.countries.splice(idx, 1);
    },
	toggleTaskList() {
      this.taskListIsVisible = !this.taskListIsVisible;
    },
  }
});

app.mount('#countries');