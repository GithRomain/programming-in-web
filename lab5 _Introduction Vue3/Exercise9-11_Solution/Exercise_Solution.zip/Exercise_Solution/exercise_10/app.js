const app = Vue.createApp({
  data() {
    return { 
       newCountry: '',
       countries: []
     };
  },
  methods: {
    addCountry() {
      this.countries.push(this.newCountry);
    },
    removeCountry(idx) {
      this.countries.splice(idx, 1);
    }
  }
});

app.mount('#countries');