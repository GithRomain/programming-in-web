const app = Vue.createApp({
  data() {
    return { countries: [] };
  },
});

app.mount('#countries');
