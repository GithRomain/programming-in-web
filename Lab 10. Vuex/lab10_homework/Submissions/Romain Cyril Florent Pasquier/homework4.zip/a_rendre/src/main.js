import { createApp } from 'vue'
import App from './App.vue'
import store from '@/store' // short for @/store/index

createApp(App).use(store).mount('#app')
