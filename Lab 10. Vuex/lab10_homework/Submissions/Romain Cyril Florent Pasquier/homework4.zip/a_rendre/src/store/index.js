// store/index.js
import { createStore } from 'vuex'

export default createStore({
    state:{
        items: [],
        itemsAll: [],
        bought: false
    },
    getters:{
        itemsCount: (state) => state.itemsAll.length
    },
    mutations: {
        INSERT_ITEM(state, item) {
            if (state.bought === true){
                state.itemsAll.push(item)
            }
            else {
                state.items.push(item)
                state.itemsAll.push(item)
            }
        },
        DELETE_ITEM(state, index) {
            state.items.splice(index,1)
            state.itemsAll.splice(index,1)
        }
    },
    actions:{
        async insertItem({commit}, payload){
            commit("INSERT_ITEM", payload)
        },
        async deleteItem({commit}, payload){
            commit("DELETE_ITEM", payload)
        }
    }
})
