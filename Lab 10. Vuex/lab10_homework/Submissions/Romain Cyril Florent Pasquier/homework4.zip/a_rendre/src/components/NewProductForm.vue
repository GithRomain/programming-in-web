<template>
  <div>
    <input type="text" v-model="name" placeholder="New product name...">
    <button @click="addItem">Submit</button>
  </div>
  <br>
  <br>
</template>

<script>
class Item {
  constructor(name) {
    this.brought = false;
    this.name = name;
    this.edit = true;
  }
}
export default {
  name: "NewProductForm",
  data(){
    return{
      name: ''
    };
  },
  methods:{
    addItem(){
      if(this.name != '') {
        this.$store.dispatch("insertItem", new Item(this.name))
      }
      else {
        alert("Enter a name of product !")
      }
    }
  }
}
</script>

<style scoped>
div
{
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
}

button{
  background-color: green;
}

button:hover {background-color: darkgreen}

button:active {
  background-color: darkgreen;
}
</style>