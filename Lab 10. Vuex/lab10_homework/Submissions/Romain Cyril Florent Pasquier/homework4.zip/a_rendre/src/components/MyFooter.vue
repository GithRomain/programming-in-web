<template>
  <div>
    <button class="all" @click="viewAll">All</button>
    <button class="notBought" @click="viewNotbought">Not bought</button>
    <button class="bought" @click="viewBought">Bought</button>
  </div>
</template>

<script>
export default {
  name: "MyFooter",
  data(){
    return{
    };
  },
  methods:{
    viewAll(){
      this.$store.state.bought = false;
      this.$store.state.items = this.$store.state.itemsAll;
    },
    viewNotbought(){
      this.$store.state.bought = false;
      this.$store.state.items = this.$store.state.itemsAll.filter(p => p.brought === false);
    },
    viewBought(){
      this.$store.state.bought = true;
      this.$store.state.items = this.$store.state.itemsAll.filter(p => p.brought === true);
    }
  }
}
</script>

<style scoped>
div
{
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.all{
  background-color: gray;
}

.all:hover {background-color: darkgray}

.all:active {
  background-color: darkgrey;
}

.notBought{
  background-color: cyan;
}

.notBought:hover {background-color: darkcyan}

.notBought:active {
  background-color: darkcyan;
}

.bought{
  background-color: blue;
}

.bought:hover {background-color: darkblue}

.bought:active {
  background-color: darkblue;
}

</style>