<template>
  <div>
    <button class="mark" @click="markAll">Mark all as bought</button>
    <button class="delete" @click="deleteAllMarked">delete all marked as bought</button>
    <p>Product remaining : {{$store.getters.itemsCount}}</p>
  </div>
  <br>
</template>

<script>
export default {
  name: "MyProduct.vue",
  data(){
    return{
    };
  },
  methods:{
    deleteItem(index){
      this.$store.dispatch("deleteItem", index)
    },
    markAll(){
      this.$store.state.items.forEach(p => p.brought = true)
    },
    deleteAllMarked(){
      this.$store.state.items = this.$store.state.items.filter(p => p.brought === false)
    }
  }
}
</script>

<style scoped>
div
{
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.mark{
  background-color: blue;
}

.mark:hover {background-color: darkblue}

.mark:active {
  background-color: darkblue;
}

.delete{
  background-color: red;
}

.delete:hover {background-color: darkred}

.delete:active {
  background-color: darkred;
}
</style>