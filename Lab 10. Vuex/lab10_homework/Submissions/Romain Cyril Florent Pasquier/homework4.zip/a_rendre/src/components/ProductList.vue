<template>
  <li v-for="(item, index) in $store.state.items" :key="item">
    <div v-if="item.edit">
      <label class="container">
        <input type="checkbox" v-model="item.brought">
        <span class="checkmark"></span>
      </label>
      <p>{{item.name}}</p>
      <button class="edit" @click="editeItem(item)">Edit</button>
      <button class="delete" @click="deleteItem(index)">Delete</button>
    </div>
    <div v-else>
      <label class="container">
        <input type="checkbox" v-model="item.brought">
        <span class="checkmark"></span>
      </label>
      <input type="text" v-model="newName" placeholder="new product name...">
      <button class="submit" @click="changeName(item)">Submit</button>
      <button class="delete" @click="deleteItem(index)">Delete</button>
    </div>
  </li>
  <br>
  <br>
  <br>
</template>

<script>
export default {
  name: "ProductList",
  data(){
    return{
      newName: ''
    };
  },
  methods:{
    deleteItem(index){
      this.$store.dispatch("deleteItem", index)
    },
    editeItem(item){
      item.edit = false;
    },
    changeName(item){
      if (this.newName != ''){
        item.name= this.newName;
        item.edit = true;
      }
      else {
        alert("Enter a Newname !")
      }
    }
  }
}
</script>

<style scoped>
li
{
  list-style-type: none;
}

div
{
  display: flex;
  flex-direction: row;
  justify-content: space-evenly;
  align-items: center;
}

p
{
  font-weight: bold;
}

.delete{
  background-color: red;
}

.delete:hover {background-color: darkred}

.delete:active {
  background-color: darkred;
}

.edit{
  background-color: orange;
}

.edit:hover {background-color: darkorange}

.edit:active {
  background-color: darkorange;
}

.submit{
  background-color: green;
}

.submit:hover {background-color: darkgreen}

.submit:active {
  background-color: darkgreen;
}
</style>