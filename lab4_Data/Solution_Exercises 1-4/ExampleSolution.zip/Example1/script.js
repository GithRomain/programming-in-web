const items = [
  { id: '1', name: 'Grzegorz Rogus', price: 399 },
  { id: '2', name: 'Jan Kowalski', price: 199 },
  { id: '3', name: 'Zwirek i Muchomorek', price: 299 },
  { id: '4', name: 'Robert King', price: 274 },
  { id: '5', name: 'Ann Rose', price: 100 },
  { id: '6', name: 'Rumburak', price: 342 },
  { id: '7', name: 'Katarzyna Nowak', price: 128 },
  { id: '8', name: 'Jan Kowalski', price: 199 },
  { id: '9', name: 'Joe Doe', price: 346 }
];

const app = document.querySelector('#app');

// 1. Add tree new element to array ( 2 to the end, 1 to the beginig)
items.push( { id: '10', name: 'Test Test', price: 500 });
items.push( { id: '11', name: 'One Two', price: 700 });
items.unshift ({ id: '0', name: 'zero zero', price: 120 } ); 

// 2. extend the array in position 5 with 3 new values. 
items.splice(5, 0, { id: '20', name: 'X Y', price: 100 }, { id: '21', name: 'Z W', price: 101 }, { id: '22', name: 'Y U', price: 102 });

// 3. replace object 3 and 4 with new items 
items.splice(2, 2, { id: '25', name: 'A B', price: 100 }, { id: '26', name: 'C D', price: 101 });

// 4. Display all value from array in your web pages in section app
items.forEach((item) => {
  app.innerHTML += `
    <li>
      ${item.id} ${item.name} - ${(item.price / 100).toFixed(2)}
    </li>
  `;
});

