
let  numbers = [1, 2, 3, 4, 5, 6, 7, 8, 8, 9];


// check if the array contains only elements smaller than 9
// result display in console
var every_result_is_smaller_than_9 = numbers.every(item => item < 9);
console.log(every_result_is_smaller_than_9);  // false

// check if the array contains any elements less than 6
// result display in console
var some_resulst_are_smaller_than_9 = numbers.some(item => item < 9);
console.log(some_resulst_are_smaller_than_9); // true

// in console dispay all odd number from array
var odd_numbers = numbers.filter(item => item % 2 == 1);
console.log(odd_numbers);        // [1, 3, 5, 7, 9]

// increment every elements from array. Result display in console.
var numbers_plus_one = numbers.map(item => item + 1);
console.log(numbers_plus_one);

//  calculate sum of all elements from array. Result dispaly in console
var sum_all_numbers = numbers.reduce((partial_sum, a) => partial_sum + a,0);
console.log(sum_all_numbers);




















// 
