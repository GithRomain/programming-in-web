const names = ['Grzegorz', 'Wiktoria', 'Mateusz', 'Ania', 'Sandra', 'Kasia', 'Izabela', 'Weronika'];


//  1. In web Pages display names which contain  sign "r".
const filterItems = (letters) => {
    return names.filter(name => name.indexOf(letters) > -1);
} 

console.log(filterItems('r')); // ['Grzegorz', 'Wiktoria', 'Sandra', 'Weronika']

let items = filterItems('r');
const app = document.querySelector('#app');
items.forEach((item) => {
  app.innerHTML += `
    <li>
      ${item}/
    </li>
  `;
});


const countries = [
    { name: 'Nigeria', continent: 'Africa'},
    { name: 'Nepal', continent: 'Asia'},
    { name: 'Angola', continent: 'Africa'},
    { name: 'Polska', continent: 'Europe'},
    { name: 'Kenia', continent: 'Africa'},
    { name: 'Grecja', continent: 'Europe'},
	{ name: 'Chiny', continent: 'Asia'}
]

// 2.  In web Pages display countries from Europe
let kraje = countries.filter(country => {
    return country.continent === 'Europe';
})
console.log(kraje); // [{name: 'Grecja', continent: 'Europe'}, {name: 'Polska', continent: 'Europe'}]

let items2 = kraje;
items2.forEach((item) => {
  app.innerHTML += `
    <li>
      ${item.name} ${item.continent}
    </li>
  `;
});


let people = [
    {"id":123, "name":"Rick Deckard", "email":"rick@bladerunner.org"},
    {"id":456, "name":"Roy Batty", "email":"roy@replicant.io"},
    {"id":789, "name":"J.F. Sebastian", "email":"j.f@tyler.com"},
    {"id":258, "name":"Pris", "email":"pris@replicant.io"}
];

// 3. Find the names of all the people who have "replicant.io" emails result display in web pages.
//arrow function version
let rn = people.filter( person => (person.email.indexOf("@replicant.io")>-1) )
.map(person => person.name );
console.log("List of replicant names:", rn);


// 4. removing duplicate values from an array duplicateName
let duplicateName = [1, 2, 5,2,1,5, 6,8,9,5,1,4,3,56,78,1];
let duplicateName2 = ['John', 'Paul', 'George', 'Ringo', 'Paul', 'Paul', 'Ringo'];

duplicateName = [...new Set(duplicateName)];
console.log(duplicateName);

duplicateName2 = [...new Set(duplicateName2)];
console.log(duplicateName2);







