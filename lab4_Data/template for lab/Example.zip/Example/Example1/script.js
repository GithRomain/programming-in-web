
const items = [
  { id: '1', name: 'Grzegorz Rogus', price: 399 },
  { id: '2', name: 'Jan Kowalski', price: 199 },
  { id: '3', name: 'Zwirek i Muchomorek', price: 299 },
  { id: '4', name: 'Robert King', price: 274 },
  { id: '5', name: 'Ann Rose', price: 100 },
  { id: '6', name: 'Rumburak', price: 342 },
   { id: '7', name: 'Katarzyna Nowak', price: 128 },
  { id: '8', name: 'Jan Kowalski', price: 199 },
  { id: '9', name: 'Joe Doe', price: 346 }
];


const app = document.querySelector('#app');


// 1. Add tree new element to array ( 2 to the end, 1 to the beginig)

// 2. extend the array in position 5 with 3 new values. 

// 3. replace object 3 and 4 with new items 

// 4. Display all value from array in your web pages in section app
