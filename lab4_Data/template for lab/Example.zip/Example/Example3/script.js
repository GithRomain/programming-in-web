const companies= [
  {name: "Company One", category: "Finance", start: 1981, end: 2004},
  {name: "Company Two", category: "Retail", start: 1992, end: 2008},
  {name: "Company Three", category: "Auto", start: 1999, end: 2007},
  {name: "Company Four", category: "Retail", start: 1989, end: 2010},
  {name: "Company Five", category: "Technology", start: 2009, end: 2014},
  {name: "Company Six", category: "Finance", start: 1987, end: 2010},
  {name: "Company Seven", category: "Auto", start: 1986, end: 1996},
  {name: "Company Eight", category: "Technology", start: 2011, end: 2016},
  {name: "Company Nine", category: "Retail", start: 1981, end: 1989}
];

const ages = [33, 12, 20, 16, 5, 54, 21, 44, 61, 13, 15, 45, 25, 64, 32];



//  1. Display in console list all company name form array


//  2.  Display in console all ages older then 18. 


//  3.  Display in console  only companies from Ratail. 

//  4.  Get 80s companies. Result display in console

//  5.  For all companies add to nme prefix "Super". Result display in console.


//  6. Sort companies by start year


//  7. Get total years for all companies 


// 8. Use chain methods.  All ages multiply twice. Only for ages greate then 40 calculate sum of ages. result display in console.  

