
const names = ['Grzegorz', 'Wiktoria', 'Mateusz', 'Ania', 'Sandra', 'Kasia', 'Izabela', 'Weronika'];


const countries = [
    { name: 'Nigeria', continent: 'Africa'},
    { name: 'Nepal', continent: 'Asia'},
    { name: 'Angola', continent: 'Africa'},
    { name: 'Polska', continent: 'Europe'},
    { name: 'Kenia', continent: 'Africa'},
    { name: 'Grecja', continent: 'Europe'},
	{ name: 'Chiny', continent: 'Asia'}
]


let people = [
    {"id":123, "name":"Rick Deckard", "email":"rick@bladerunner.org"},
    {"id":456, "name":"Roy Batty", "email":"roy@replicant.io"},
    {"id":789, "name":"J.F. Sebastian", "email":"j.f@tyler.com"},
    {"id":258, "name":"Pris", "email":"pris@replicant.io"}
];

let duplicateName = ['John', 'Paul', 'George', 'Ringo', 'Paul', 'Paul', 'Ringo'];


//  1. In web Pages display names which contain  sign "r".

// 2.  In web Pages display countries from Europe

// 3. Find the names of all the people who have "replicant.io" emails. result dislay in web pages.

// 4. removing duplicate values from an array duplicateName