
let  numbers = [1, 2, 3, 4, 5, 6, 7, 8, 8, 9];


// check if the array contains only elements smaller than 9
// result display in console


// check if the array contains any elements less than 6
// result display in console

// in console dispay all odd number from array

// increment every elements from array. Result display in console.

//  calculate sum of all elements from array. Result dispaly in console




