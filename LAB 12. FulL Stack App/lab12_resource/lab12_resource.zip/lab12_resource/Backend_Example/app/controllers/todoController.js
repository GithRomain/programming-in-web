// import Todo Model
const  Todo = require("../models/todoModel");

// DEFINE CONTROLLER FUNCTIONS

// listAllTodos function - To list all todos
exports.listAllTodos = (req, res) => {
    console.log("Read action for all");
    Todo.find()
    .then(comments => {
        res.status(200).send(comments);
    })
    .catch(err => {
        res.status(500).send({ message: err.message});
    });
};
 
// createNewTodo function - To create new todo
exports.createNewTodo = (req, res) => {
    console.log("Create action for ");
    console.log(req.body.text + " " + req.body.status );
 
    let  newTodo = new Todo (req.body);
    newTodo.save()
    .then(data => {
        res.status(201).send(data);
    }).catch(err => {
        res.status(500).send({ message: err.message});
    });
};

// updateTodo function - To update todo status by id
exports.updateTodo = (req, res) => {
    console.log("Update action for ");
    console.log( req.params);

    Todo.findOneAndUpdate({ _id: req.params.id }, req.body, {new: true})
    .then(todo => {
        if(!todo) {
            return res.status(404).send({
                message: "Todo item not found with id " + req.params.id
            });
        }
        res.status(201).send(todo);
    })
    .catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Todo Item not found with id " + req.params.id
            });                
        }
        return res.status(500).send({
            message: "Error updating todo item with id " + req.params.id
        });
    });
};

// deleteTodo function - To delete todo by id
exports.deleteTodo = async ( req, res) => {
    console.log("Delete action for ");
    console.log(req.params.id);
    await  Todo.deleteOne({ _id:req.params.id }, (err) => {
        if (err) {
          return res.status(404).send(err);
        }
        res.status(200).json({ message:"Todo successfully deleted"});
    });
};

// deleteTodo function - To delete todo by id
exports.findOneTodo = (req, res) => {
    console.log("Get action for one item ");
    console.log(req.params.id );
    Todo.findById(req.params.id)
    .then(todo => {
        if(!todo) {
            return res.status(404).send({
                message: "Todo item not found with id " + req.params.id
            });            
        }
        res.send(todo);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Todo item not found with id " + req.params.id
            });                
        }
        return res.status(500).send({
            message: "Error retrieving Todo item with id " + req.params.id
        });
    });
};
