// get element from the page and assign it to a variable
const someButton = document.querySelector('#some-button')

// Nodes - elements + text nodes (incl. new lines, spaces etc.)
console.log('-----------NODES-------')
console.log(someButton.parentNode)
console.log(someButton.nextSibling)
console.log(someButton.previousSibling)
console.log(someButton.childNodes)

console.log('--------ALL NODES--------')
console.log(someButton.parentNode.childNodes) // childNodes include not only our button and span, but also some text nodes.

// Elements - html tags. That's what you want most of the time.
console.log('--------ELEMENTS-------')
console.log(someButton.parentElement) // the same as parentNode most of the time with exception of document.parentElement
console.log(someButton.nextElementSibling)
console.log(someButton.prevElementSibling)
console.log(someButton.children)