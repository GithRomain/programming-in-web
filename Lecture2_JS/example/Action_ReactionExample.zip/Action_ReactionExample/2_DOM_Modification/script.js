const container = document.querySelector('#container');
const tcButton = document.querySelector('#text-content');
const ihButton = document.querySelector('#inner-html');

console.log(container.textContent);
console.log(container.innerText); // aware of text styling/visibility to user
console.log(container.innerHTML);

tcButton.addEventListener('click', () => { 
  container.textContent = 'No bacon please';
})

ihButton.addEventListener('click', () => {
  container.innerHTML = '<a href="http://www.google.com">Careful with user input</a>';
})