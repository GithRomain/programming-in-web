const container = document.querySelector('#container');

container.addEventListener('click', (e) => {
  alert(e.target.textContent);
})