const someButton = document.querySelector('#some-button');


someButton.addEventListener('click',  alertText);

function alertText() {
  alert(someButton.textContent); // comment
}


/* 

addEventListener('click', (e) => {
alert(someButton.textContent);
});

someButton.onclick = function alertText() {
  alert(someButton.textContent); // comment
}
*/