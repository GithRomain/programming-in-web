const styleToggler = document.querySelector('#style-toggler');
const myDiv = document.querySelector('#styled-div');

styleToggler.addEventListener('click', () => {
 // 1 version 
//   myDiv.style.backgroundColor = 'blue';
 //  console.log(myDiv.classList);
 
// 2 version
//   myDiv.classList.add('another-class');

//  3 version 
     myDiv.classList.toggle('another-class');

//   myDiv.classList.remove('some-class');
});