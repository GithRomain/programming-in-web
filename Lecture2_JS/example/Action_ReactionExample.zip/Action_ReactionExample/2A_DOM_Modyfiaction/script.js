const myImg = document.querySelector('#hedgehog');

const myButton = document.querySelector('#img-switcher');

myButton.addEventListener('click', () => {
  myImg.src = "img2.jpg";
});