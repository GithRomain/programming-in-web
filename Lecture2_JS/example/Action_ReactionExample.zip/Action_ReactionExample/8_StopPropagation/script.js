const section = document.querySelector('section');
const div = document.querySelector('div');
const p = document.querySelector('p');

section.addEventListener('click', (e) => alert('section'));
div.addEventListener('click', (e) => alert('div'));
// div.addEventListener('click', (e) => alert('div'), true);
p.addEventListener('click', (e) => {
  e.stopPropagation();
  alert('p')
});