const button = document.querySelector('button');

/*
button.addEventListener('click', (e) => {
  alert('Clicked!');
});*/

// button.removeEventListener('click', /* what should we write here??? */);

// Solution - keep reference to the handling function
 const alertClick = (e) => {
   alert('Clicked!');
   button.removeEventListener('click', alertClick);
 }

 button.addEventListener('click', alertClick)