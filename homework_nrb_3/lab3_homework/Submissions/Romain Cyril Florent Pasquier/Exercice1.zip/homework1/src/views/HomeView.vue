<template>
    <MessageHome msg="Shopping List App"/>
</template>

<script>
// @ is an alias to /src
import MessageHome from '@/components/AddToList.vue'

export default {
  name: 'HomeView',
  components: {
    MessageHome
  }
}
</script>
