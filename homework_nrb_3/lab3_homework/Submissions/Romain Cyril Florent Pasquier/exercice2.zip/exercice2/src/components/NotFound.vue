<template>
  <p>
    404 SORRY COULDN'T FIND IT!!!
  </p>
</template>

<script>

export default {
  name: 'NotFound'
};

</script>

<style scoped>
p {
  font-weight: bold;
  font-size: 50px;
  text-align: center;
  color: #f10b0b;
}
</style>
