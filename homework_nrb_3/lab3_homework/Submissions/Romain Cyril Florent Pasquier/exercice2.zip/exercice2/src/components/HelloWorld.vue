<template>
  <section>
    <h1>Our Shop :</h1>
    <img src="../assets/1200px-FutureShop_HFX_2007.jpg" width="80%">
    <br><br>
    <br><br>
    Much like how wrappers and gift presentations matter a lot when you’re giving presents, how you show-off your merchandise to customers can do wonders (or spell disaster) when it comes to how your store and products are perceived.
    <br><br>
    With the holidays coming up, it’s more important than ever to ensure that your displays and merchandise stand out from the competition, attract the right shoppers, and most importantly, close sales.
    <br><br>
    To help you do that, below are six store and product presentation tips that you could implement.
    <br><br>
    Storefront
    Let’s start with your storefront. Holiday shoppers will likely be bombarded with eye-catching signs and displays when they hit the mall or shopping center, so invest in your store’s curb appeal and find ways to be distinctive.
    <br><br>
    Here some steps you could take:
    <br><br>
    Freshen up your window displays
    Since every store is different, there aren’t any hard and fast rules for setting up your window displays. But one best practice to keep in mind for the holidays is to keep your displays fresh. See to it that merchandise and signage are relevant to the season.
    <br><br>
    You may also want to update your displays more frequently. You’re likely getting a lot of repeat walk-by traffic (ex: people heading to work, shoppers who live in the neighborhood, etc), so having the same old displays could result in people ignoring your shop.
    <br><br>
    Stay on top of maintenance
    It may be tempting to skip that much-needed paint job or to postpone cleaning your windows util the end of the week, but these maintenance steps can make or break your curb appeal.
    <br><br>
    Getting a fresh coat of paint, for example, can make your store look brand new, while sprucing up your storefront (i.e. cleaning your windows, sweeping the outside of your store) can make your store shine.
    <br><br>
    Include curbside “extras”
    If you can, set up your storefront so it adds value to potential customers. Find ways to make your curbside more useful to passers-by.
    <br><br>
    One of my favorite examples of this in action comes from Snyder Cycles, a bike shop and steel bike frame manufacturer with a storefront in Atlanta, GA. The storeowners put out bike racks outside the shop so cyclers (their target customers) have a space to park their bikes.
    <br>
    There are also pet shops that have started putting water bowls outside their stores to encourage customers and their furry companions to stop in front of the store and look around.
    <br><br>
    In-store displays and merchandise
    Now that we’ve covered what you can do on the outside of your store, let’s talk about the in-store display and merchandising efforts you can make to improve product presentation:
    <br><br>
    Avoid overstuffing your store
    Stuffing your shelves with as much merchandise as you can will not only make your shop look cluttered, it could also overwhelm and drive shoppers away.
    <br><br>
    Remember, consumers are constantly barraged with messages and choices, and it’s not uncommon for them to abandon a store or purchase when they feel too overwhelmed. So rather than trying to push more merchandise, strive to curate thoughtful assortments and make it easy for customers to find what they’re looking for.
    <br><br>
    On a more practical level, stores that are crowded with shelves and displays are more prone to the “butt-brush effect.” Coined Paco Underhill, author of the book Why We Buy, the butt-brush effect is a phenomenon wherein customers would move away from a display if they're brushed from behind.
    <br><br>
    Underhill described the effect in his book as follows:
    <br><br>
    While reviewing the tape to study how shoppers negotiated the doorway during busy times, we began to notice something weird about the tie rack. Shoppers would approach it, stop and shop until they were bumped once or twice by people heading into or out of the store. After a few such jostles, most of the shoppers would move out of the way, abandoning their search for neckwear. We watched this over and over until it seemed clear that shoppers — women especially, though it was also true of men to a lesser extent — don’t like being brushed or touched from behind. They’ll even move away from merchandise they’re interested in to avoid it.
    <br><br>
    Break “seas of racks” with thoughtful displays or speed bumps
    Long, uninterrupted racks or shelves could result in shoppers skipping over some of your merchandise.
    <br><br>
    Prevent this by putting breaks or speed bumps between repetitive fixtures. This could help freshen up the flow of merchandise, and it’ll give customers a break from all the shelves or racks so they can re-focus and pay attention to your products.
    <br><br>
    Give shoppers ideas on how to put items together
    Make it easier for customers to decide what to purchase by giving them ideas on how different items can be put together. This tactic works especially well for apparel and homeware.
    <br><br>
    Consider what Target is doing. Fortune reports that the retail giant recently revamped its stores to give them a more “department store” look and feel. One of the things it did was to set up mannequins to show off outfit ideas. The result? According to Brian Cornell, Target’s CEO, the sales of items worn by mannequins increased by 30%.
    <br><br>
    Target is doing something similar in its houseware departments.
    <br><br>
    According to Fortune (emphasis added):
    <br><br>
    Target has been rolling out what it calls “home innovation” areas that showcase housewares in vignettes that help shoppers imagine how items would appear in an actual dining room or kitchen rather than placed unimaginatively on a shelf. By next month, those enhanced home areas will be at 262 Target stores. So far, Cornell said, items merchandised in that manner sell three to four times better than the average for the home category.
    <br><br>
    Weigh in
    Now we’d love to hear from you. What are your best display and merchandising tips for the holidays (and beyond)? Leave a comment and let us know.
  </section>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
section{
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
