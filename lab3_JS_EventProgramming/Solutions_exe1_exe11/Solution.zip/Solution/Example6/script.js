const container = document.querySelector('#container');
const x_pos = document.querySelector('#mouseX');
const y_pos = document.querySelector('#mouseY');

container.addEventListener('click', (e) => {
   alert(e.target.textContent);
   console.log(e);
})

container.addEventListener('mousemove', getMousePosition);

function getMousePosition(evt) {
     y_pos.value = evt.offsetY;
     x_pos.value = evt.offsetX;
}