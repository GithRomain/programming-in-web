const sel_Header = document.querySelector('#heading');
const sel_Color = document.querySelector('#body');

sel_Header.addEventListener('change', changehead);
sel_Color.addEventListener('change', changebody);

function changehead() {
  i = document.form1.heading.selectedIndex;
  headcolor = document.form1.heading.options[i].value;
  document.getElementById("head1").style.color = headcolor;
}
function changebody() {
  i = document.form1.body.selectedIndex;
  doccolor = document.form1.body.options[i].value;
  document.getElementById("p1").style.color = doccolor;
}