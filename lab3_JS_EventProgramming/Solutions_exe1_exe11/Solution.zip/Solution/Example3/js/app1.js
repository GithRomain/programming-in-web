let button1 = document.querySelector('#myButton1');
let button2 = document.querySelector('#myButton2');
let cb1 = document.querySelector('#myCheck');

button1.addEventListener('click', addEvent);
button2.addEventListener('click', deleteEvent);
cb1.addEventListener('change', secondFunction);

let count = 0;

    function processClick(evt) {
	      let elem = document.querySelector('#wynik');
	      count++;
		  elem.innerHTML = 'sum of counter : ' + count; // podmiana starej zawartosci
	};
  
    function addEvent(evt) {
	  let b = document.querySelector("#myButton");
      b.addEventListener('click', processClick);
	  console.log("Dodano nacisniecie przycisku");
 	};
	
	function deleteEvent(evt) {
	  let b = document.querySelector("#myButton");
      b.removeEventListener('click', processClick);
	  count = 0;
	  let elem = document.querySelector('#wynik');
	  elem.innerHTML = "Counter is turn off"; // podmiana starej zawartosci
	  console.log("Usunieto zdarzenie nacisniecie przycisku");
	};

    function secondFunction() {
        console.log("check test");
        let b = document.querySelector("#myButton");
        if (cb1.checked)  {
           b.addEventListener('click', alertMessage);
           console.log("Second function was added");
        }
        else {
           b.removeEventListener('click', alertMessage);
           console.log("Second function was deleted");
        }
    };

    function alertMessage() {
        alert("Greeting from second function");
    }