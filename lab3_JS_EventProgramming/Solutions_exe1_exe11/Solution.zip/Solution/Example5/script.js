const form = document.querySelector('form');

form.addEventListener('submit', (e) => {

  e.preventDefault();
  // to get form values use FormData and Object.fromEntries
  const input = form.querySelector("input").value;
  alert( " sending " + input);
});