const container = document.querySelector('#button1');
const container2 = document.querySelector('#button2');
const container3 = document.querySelector('#button3');

container.addEventListener('click', add);
container2.addEventListener('click', del);
container3.addEventListener('click', reset);


function add() {
  var val = document.querySelector('#newNumber').value;
  if((val !== undefined) && (val !== "")) {
     var ul = document.querySelector("#numbers");
     var newNumber = document.createElement("li");
     newNumber.textContent = val;
     ul.append(newNumber);    // dodaje do listy
  }
}
 
function reset() {
  var ul = document.querySelector("#numbers");
   ul.innerHTML = ""; 
}

function del() {
   let list = document.getElementById("numbers");
   list.removeChild(list.firstChild);
  
  //  druga wersja
  // list.removeChild(list.childNodes[0]);
}