let button = document.querySelector('#button');

button.addEventListener('click', imageSwap());


   const ile = 3;
    const first= "1.jpg";
	const second= "2.jpg";
	const third= "3.jpg";
	const images = [ first, second, third];
  
    var flag = 0;
 
    function imageSwap() {
	 	let elem = document.querySelector('img');
		flag++;
		
		// optimal version
		elem.setAttribute("src", images[flag%ile]);  
		elem.className= "image" + (flag%ile+1);
	};



	// clasical version 
	/*   if (flag%2==0) {
	       elem.src = first;   
		   elem.style.border = "3px red solid";   
		}
		else {
           elem.setAttribute("src", second);	
		   elem.style.border = "3px blue solid"; 
		}  */


	